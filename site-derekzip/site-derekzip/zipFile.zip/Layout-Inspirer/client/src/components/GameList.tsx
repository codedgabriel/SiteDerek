import { motion } from "framer-motion";
import { Gamepad2 } from "lucide-react";
import type { Game } from "@shared/schema";

interface GameListProps {
  games: Game[];
}

export function GameList({ games }: GameListProps) {
  return (
    <div className="space-y-3">
      {games.map((game, index) => (
        <motion.div
          key={game.id}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 + (index * 0.1), duration: 0.5 }}
          className="flex items-center gap-4 bg-white/5 hover:bg-white/10 p-3 rounded-lg border border-white/5 hover:border-primary/30 transition-all duration-300 group cursor-default"
        >
          <div className="w-12 h-12 rounded-md bg-black/50 overflow-hidden flex-shrink-0 border border-white/10 group-hover:border-primary/50 transition-colors">
            {game.imageUrl ? (
              <img src={game.imageUrl} alt={game.title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Gamepad2 className="w-5 h-5 text-white/30" />
              </div>
            )}
          </div>
          <div>
            <h4 className="font-medium text-white/90 group-hover:text-primary transition-colors">{game.title}</h4>
            <div className="h-0.5 w-0 group-hover:w-full bg-primary mt-1 transition-all duration-300 opacity-50"></div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
