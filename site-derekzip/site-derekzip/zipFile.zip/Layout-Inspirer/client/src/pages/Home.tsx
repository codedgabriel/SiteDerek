import { useProfile, useGames } from "@/hooks/use-profile";
import { ProfileLayout } from "@/components/ProfileLayout";
import { DiscordCard } from "@/components/DiscordCard";
import { GameList } from "@/components/GameList";
import { Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: profile, isLoading: profileLoading, error: profileError } = useProfile();
  const { data: games, isLoading: gamesLoading } = useGames();

  const isLoading = profileLoading || gamesLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-primary">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (profileError || !profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white/50 gap-4">
        <AlertCircle className="w-12 h-12 text-red-900" />
        <p>Failed to load profile data.</p>
      </div>
    );
  }

  return (
    <ProfileLayout>
      <div className="space-y-8 pb-12">
        {/* Header / Hero */}
        <div className="text-center space-y-4">
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="w-32 h-32 mx-auto rounded-full p-1 bg-gradient-to-br from-primary via-black to-primary shadow-[0_0_40px_-10px_rgba(139,0,0,0.6)]"
          >
            <div className="w-full h-full rounded-full overflow-hidden bg-black border-4 border-black">
              {profile.avatarUrl ? (
                <img 
                  src={profile.avatarUrl} 
                  alt={profile.name} 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                />
              ) : (
                <div className="w-full h-full bg-zinc-900" />
              )}
            </div>
          </motion.div>
          
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="text-4xl font-bold tracking-tight text-white mb-2 font-display uppercase">
              {profile.name}
            </h1>
            <p className="text-primary font-medium tracking-wide uppercase text-xs">
              {profile.subtext}
            </p>
          </motion.div>
        </div>

        {/* About Section */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.25 }}
          className="bg-zinc-900/30 backdrop-blur-sm border border-white/5 rounded-xl p-6 text-center shadow-lg"
        >
          <p className="text-white/80 leading-relaxed font-light">
            {profile.about}
          </p>
        </motion.div>

        {/* Discord Card */}
        <DiscordCard profile={profile} />

        {/* Games Section */}
        <div className="space-y-4">
          <motion.h3 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.35 }}
            className="text-sm font-bold text-white/40 uppercase tracking-widest text-center"
          >
            Favorite Games
          </motion.h3>
          
          {games && games.length > 0 && (
            <GameList games={games} />
          )}
        </div>

        {/* Footer */}
        <motion.footer 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center text-white/20 text-xs py-8"
        >
          <p>© {new Date().getFullYear()} {profile.name}. All rights reserved.</p>
        </motion.footer>
      </div>
    </ProfileLayout>
  );
}
