## Packages
framer-motion | For smooth animations and entry effects
lucide-react | For iconography (Discord, etc.)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
