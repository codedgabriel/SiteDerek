import { motion } from "framer-motion";
import type { Profile } from "@shared/schema";

interface AboutMeProps {
  profile: Profile;
}

export function AboutMe({ profile }: AboutMeProps) {
  return (
    <motion.div 
      initial={{ y: 20, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: true }}
      transition={{ delay: 0.2, duration: 0.6 }}
      className="relative group w-full"
    >
      <div className="absolute -inset-2 bg-gradient-to-r from-primary/60 via-primary/30 to-primary/60 rounded-[2rem] blur-xl opacity-30 group-hover:opacity-60 transition duration-1000 group-hover:duration-200"></div>
      <div className="relative bg-[#0a0a0a]/80 backdrop-blur-2xl border border-white/10 rounded-[1.5rem] p-10 shadow-2xl overflow-hidden">
        <div className="absolute top-0 left-0 w-2 h-full bg-primary/80"></div>
        <div className="flex flex-col items-center gap-6">
          <div className="bg-primary/20 px-4 py-1.5 rounded-full border border-primary/30">
            <span className="text-primary font-black tracking-[0.3em] text-[10px] uppercase">Profile History</span>
          </div>
          <p className="text-white/95 leading-relaxed font-light text-xl italic text-center relative max-w-2xl px-6">
            <span className="text-primary text-6xl absolute -top-8 -left-2 opacity-40 font-serif leading-none select-none">“</span>
            {profile.about}
            <span className="text-primary text-6xl absolute -bottom-16 -right-2 opacity-40 font-serif leading-none select-none">”</span>
          </p>
        </div>
      </div>
    </motion.div>
  );
}
