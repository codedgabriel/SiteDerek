import { useQuery } from "@tanstack/react-query";
import { Game, Profile } from "@shared/schema";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { SiDiscord } from "react-icons/si";
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';

export default function Home() {
  const { data: profile, isLoading: profileLoading } = useQuery<Profile>({
    queryKey: ["/api/profile"],
  });

  const { data: games, isLoading: gamesLoading } = useQuery<Game[]>({
    queryKey: ["/api/games"],
  });

  const [emblaRef] = useEmblaCarousel(
    { 
      loop: true,
      dragFree: true,
      containScroll: false,
      align: "center"
    }, 
    [Autoplay({ delay: 2000, stopOnInteraction: false, stopOnMouseEnter: true })]
  );

  if (profileLoading || gamesLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#0a0000]">
        <div className="w-12 h-12 border-4 border-red-900 border-t-red-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0000] text-zinc-100 flex flex-col items-center">
      <div className="max-w-2xl w-full px-6 py-20 flex flex-col items-center gap-16 relative">
        {/* Background Glow */}
        <div className="fixed inset-0 bg-[radial-gradient(circle_at_50%_20%,_#450a0a_0%,_transparent_50%)] pointer-events-none opacity-40" />

        {/* Hero Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center text-center gap-4 relative z-10"
        >
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-red-900 rounded-full blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <Avatar className="w-32 h-32 border-2 border-red-900/50">
              <AvatarImage src={profile?.avatarUrl} />
              <AvatarFallback className="bg-red-950 text-red-100 text-4xl">R</AvatarFallback>
            </Avatar>
          </div>
          <h1 className="text-5xl font-bold tracking-tighter text-white drop-shadow-[0_0_15px_rgba(255,0,0,0.3)]">
            {profile?.name}
          </h1>
          <p className="text-red-500/80 font-mono tracking-widest text-sm uppercase">
            {profile?.subtext}
          </p>
        </motion.section>

        {/* About Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="w-full relative z-10"
        >
          <Card className="bg-red-950/10 border-red-900/20 backdrop-blur-sm overflow-hidden relative">
            <div className="absolute top-0 left-0 w-1 h-full bg-red-800" />
            <CardContent className="p-8">
              <p className="text-zinc-300 leading-relaxed whitespace-pre-line text-lg">
                {profile?.about}
              </p>
            </CardContent>
          </Card>
        </motion.section>
      </div>

      {/* Games Carousel - Full Width Container */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="w-full flex flex-col gap-6 z-10 my-10"
      >
        <div className="max-w-2xl mx-auto w-full px-6">
          <h2 className="text-xs uppercase tracking-[0.3em] text-red-700 font-bold">
            Current Games
          </h2>
        </div>
        
        <div className="relative w-full group overflow-hidden">
          {/* Edge Gradients/Faders */}
          <div className="absolute left-0 top-0 bottom-0 w-[15%] bg-gradient-to-r from-[#0a0000] via-[#0a0000]/90 to-transparent z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-[15%] bg-gradient-to-l from-[#0a0000] via-[#0a0000]/90 to-transparent z-10 pointer-events-none" />
          
          <div className="overflow-hidden cursor-grab active:cursor-grabbing px-[15%]" ref={emblaRef}>
            <div className="flex -ml-4">
              {games?.map((game) => (
                <div key={game.id} className="flex-[0_0_200px] min-w-0 pl-4">
                  <div className="aspect-[2/3] rounded-xl bg-gradient-to-b from-red-950/40 to-black border border-red-900/30 flex flex-col items-center justify-center p-4 text-center gap-3 shadow-lg relative overflow-hidden group/item transition-all hover:border-red-600/50">
                    {/* Imagem da capa */}
                    {(game.imagePath || game.imageUrl) && (
                      <img 
                        src={game.imagePath || game.imageUrl} 
                        alt={game.title}
                        className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover/item:opacity-100 transition-opacity"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    )}
                    
                    <div className="absolute inset-0 bg-red-900/10 opacity-40 group-hover/item:opacity-10 transition-opacity" />
                    <div className="text-red-900/20 text-6xl font-black absolute inset-0 flex items-center justify-center pointer-events-none uppercase">
                      {game.title[0]}
                    </div>
                    <div className="absolute inset-0 flex items-end p-4 bg-gradient-to-t from-black via-black/40 to-transparent">
                      <span className="text-sm font-bold text-zinc-100 drop-shadow-md z-10 line-clamp-2">
                        {game.title}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      <div className="max-w-2xl w-full px-6 pb-20 flex flex-col items-center gap-16 relative">
        {/* Discord Profile Card */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="w-full relative z-10"
        >
          <Card className="bg-[#111214] border-red-900/30 overflow-hidden relative group">
            <div className="h-24 bg-red-900/40 relative">
               <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] opacity-20" />
               <div className="absolute inset-0 bg-gradient-to-t from-[#111214] to-transparent" />
            </div>
            <CardContent className="p-6 pt-0 relative">
              <div className="relative -top-12 flex flex-col gap-4">
                <div className="relative inline-block">
                  <Avatar className="w-24 h-24 border-[6px] border-[#111214] rounded-full">
                    <AvatarImage src={profile?.avatarUrl} />
                    <AvatarFallback className="bg-red-950 text-red-100 text-3xl">R</AvatarFallback>
                  </Avatar>
                  <div className="absolute bottom-1 right-2 w-6 h-6 bg-green-500 border-[4px] border-[#111214] rounded-full shadow-lg" title="Online" />
                </div>
                
                <div className="space-y-1">
                  <h3 className="text-2xl font-bold text-white flex items-center gap-2">
                    {profile?.discordName} <SiDiscord className="w-5 h-5 text-zinc-400" />
                  </h3>
                  <p className="text-xs text-zinc-400 font-mono tracking-tighter opacity-70">@{profile?.discordId}</p>
                </div>

                <div className="h-[1px] bg-zinc-800 my-2 opacity-50" />

                <div className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="text-[10px] uppercase font-bold text-zinc-500 tracking-widest">About Me</h4>
                    <p className="text-sm text-zinc-300 font-sans leading-relaxed whitespace-pre-line">
                      {profile?.discordAbout}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.section>

        <footer className="text-zinc-600 text-[10px] uppercase tracking-[0.2em] font-mono mt-10 relative z-10">
          &copy; {new Date().getFullYear()} RYZEKS • DESIGN BY UMREON
        </footer>
      </div>
    </div>
  );
}
