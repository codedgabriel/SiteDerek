import { useProfile, useGames } from "@/hooks/use-profile";
import { ProfileLayout } from "@/components/ProfileLayout";
import { DiscordCard } from "@/components/DiscordCard";
import { GameList } from "@/components/GameList";
import { AboutMe } from "@/components/AboutMe";
import { Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: profile, isLoading: profileLoading, error: profileError } = useProfile();
  const { data: games, isLoading: gamesLoading } = useGames();

  const isLoading = profileLoading || gamesLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-primary">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (profileError || !profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white/50 gap-4">
        <AlertCircle className="w-12 h-12 text-red-900" />
        <p>Failed to load profile data.</p>
      </div>
    );
  }

  return (
    <ProfileLayout>
      <div className="space-y-12 pb-24 max-w-4xl mx-auto">
        {/* Header / Hero */}
        <div className="text-center space-y-6">
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="w-40 h-40 mx-auto rounded-full p-1 bg-gradient-to-br from-primary via-black to-primary shadow-[0_0_60px_-10px_rgba(139,0,0,0.8)]"
          >
            <div className="w-full h-full rounded-full overflow-hidden bg-black border-4 border-black">
              {profile.avatarUrl ? (
                <img 
                  src={profile.avatarUrl} 
                  alt={profile.name} 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                />
              ) : (
                <div className="w-full h-full bg-zinc-900" />
              )}
            </div>
          </motion.div>
          
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <h1 className="text-5xl font-black tracking-tighter text-white mb-2 font-display uppercase italic">
              {profile.name}
            </h1>
            <p className="text-primary font-bold tracking-[0.5em] uppercase text-[10px] opacity-80">
              {profile.subtext}
            </p>
          </motion.div>
        </div>

        {/* About Section */}
        <AboutMe profile={profile} />

        {/* Discord Card */}
        <DiscordCard profile={profile} />

        {/* Games Section */}
        <div className="space-y-6">
          <motion.h3 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-[10px] font-black text-primary uppercase tracking-[0.4em] text-center"
          >
            Favorite Games
          </motion.h3>
          
          {games && games.length > 0 && (
            <GameList games={games} />
          )}
        </div>

        {/* Footer */}
        <motion.footer 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center text-white/10 text-[9px] font-bold uppercase tracking-widest pt-12"
        >
          <p>© {new Date().getFullYear()} {profile.name}. Designed for the elite.</p>
        </motion.footer>
      </div>
    </ProfileLayout>
  );
}
